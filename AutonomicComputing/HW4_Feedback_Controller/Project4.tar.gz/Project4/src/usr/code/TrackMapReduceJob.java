package usr.code;

import java.io.File;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
 

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.JobID;
import org.apache.hadoop.mapred.JobStatus;
import org.apache.hadoop.mapred.RunningJob;
import org.apache.hadoop.mapred.TaskReport;
import org.apache.hadoop.mapreduce.TaskID;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;




public class TrackMapReduceJob {
	
	public static String xmlFilePath="/usr/local/hadoop/conf/fair-scheduler.xml";
	
	public static boolean XMLEditor(int maxValue, String type){
		try{
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(xmlFilePath);

			Node pool = document.getElementsByTagName("pool").item(0);
			NodeList nodes = pool.getChildNodes();

			for (int i = 0; i < nodes.getLength(); i++) {
				Node element = nodes.item(i);
				if (type.equals(element.getNodeName())) {
					element.setTextContent(Integer.toString(maxValue));
					System.out.println(element.getTextContent());
				}
			}

			// write the DOM object to the file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();

			Transformer transformer = transformerFactory.newTransformer();
			DOMSource domSource = new DOMSource(document);

			StreamResult streamResult = new StreamResult(new File(xmlFilePath));
			transformer.transform(domSource, streamResult);

			System.out.println("The XML File was updated with maxMaps: "+maxValue);
			return true;

		} catch (ParserConfigurationException pce) {
			pce.printStackTrace();
			return false;
		} catch (TransformerException tfe) {
			tfe.printStackTrace();
			return false;
		} catch (IOException ioe) {
			ioe.printStackTrace();
			return false;
		} catch (SAXException sae) {
			sae.printStackTrace();
			return false;
		}
	}
	public static void main(String[] args) throws Exception {
	    
		if(args.length<3){
			System.out.println("Please provide inputs. Usage: TrackMapReduceJob <jobId> <referencePercentage> <noOfSlaveNodes>");
			System.out.println("=================================================================================");
			System.out.println("jobId: ID of the MapRecude Job started for WordCountPair.java \n or any other MapReduce Job");
			System.out.println("referencePercentage: input to maintain the mapper performance close to reference value \n by increase or decrease the number of mappers");
			System.out.println("noOfSlaveNodes: number of slaves nodes to avoid increase no. of mappers above threshold \n (2 mapper per nodes)");
			System.out.println("=================================================================================\n exit program");
			System.exit(0);
		}
		
	    String[] inputData={args[0].toString(),args[1].toString(),args[2].toString()};
	    int thresEff=Integer.parseInt(inputData[1]);
	    int maxMapperValue=Integer.parseInt(inputData[2])*2;
	    int currentMaxMapper=1;
	    int timmerCheck=0;
	    Configuration conf = new Configuration();
	    JobClient jobClient= new JobClient(new JobConf(conf));
	    JobID jobId=JobID.forName(inputData[0]);
	    RunningJob runningJob=jobClient.getJob(jobId);
	    //runningJob.
	    TaskReport[] taskReport=jobClient.getMapTaskReports(jobId);
	    String taskID=runningJob.getTaskCompletionEvents(0)[1].getTaskId();
	    TaskID firstCompletedTaskID = runningJob.getTaskCompletionEvents(0)[1].getTaskAttemptId().getTaskID();
		    
	    for(TaskReport tr:taskReport){
	    	tr.getTaskID().equals(taskID);
	    	System.out.println(taskID+"--"+tr.getTaskID());
	    }
	    
	    long startTime=taskReport[0].getStartTime();
	    long curTime=System.currentTimeMillis();
	    
	    try{
		    FileWriter f=new FileWriter("/usr/code/perf.txt");
			BufferedWriter bw=new BufferedWriter(f);
			float prog;
			
			while(!runningJob.isComplete()){//data.isJobComplete()){
				prog=(float)runningJob.mapProgress();//data.getMapProgress();
				curTime=System.currentTimeMillis();
				float timeLapsed=(float)(curTime-startTime);
				float efficiency= ((prog)/(timeLapsed)*10000000);
				bw.write(Float.toString(prog));
				if(efficiency<thresEff){
					if(currentMaxMapper<maxMapperValue){
						currentMaxMapper++;
						if(XMLEditor(currentMaxMapper, "maxMaps")){
							System.out.println("Max Mapper updated to: "+currentMaxMapper+"\n waiting for effect of MaxMapper change.");
							while(timmerCheck<8){
								System.out.print("..");
								timmerCheck++;
								Thread.sleep(1000);
							}
							System.out.println();
							timmerCheck=0;
						}else{
							System.out.println("Error in updating the max value of mapper");
						}
					}
				}else{
					if(currentMaxMapper>1 && currentMaxMapper<=maxMapperValue){
						currentMaxMapper--;
						if(XMLEditor(currentMaxMapper, "maxMaps")){
							System.out.println("Max Mapper updated to: "+currentMaxMapper+"\n waiting for effect of MaxMapper change.");
							while(timmerCheck<5){
								System.out.print("..");
								timmerCheck++;
								Thread.sleep(1000);
							}
							System.out.println();
							timmerCheck=0;
						}else{
							System.out.println("Error in updating the max value of mapper");
						}
					}
				}
				
				System.out.println("Mapper %completed: "+prog+" efficiency (%): "+efficiency +" timelappsed: "+timeLapsed +" current: "+curTime+" start: "+taskReport[0].getStartTime());
		    	Thread.sleep(1000);
			}
			if(XMLEditor(1, "maxMaps")){
				System.out.println("=================================================================================");
				System.out.println("MaxMaps value restored to : 1");
				System.out.println("=================================================================================");
			}else{
				System.out.println("=================================================================================");
				System.out.println("MaxMaps value restored ERROR: manual restore needed");
				System.out.println("location: /usr/local/hadoop/conf/fair-scheduler.xml");
				System.out.println("=================================================================================");
			}
		    bw.close();
	    }catch(IOException e){
				e.printStackTrace();
		}

	   
	  }
}
